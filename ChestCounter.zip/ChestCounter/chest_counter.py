"""
Chest Counter for Fortnite - desktop app for Windows.

Counts the chests you loot in Fortnite by reading the replays (.replay) the game saves after each match.
Inside each replay every chest records which player opened it, so only your chests are counted: with or
without the "Search" prompt, any rarity, chests you break open, and without depending on quests.

It never touches the game or its memory: it only reads files Fortnite already saves on your PC.
Replay parser: FortniteReplayDecompressor (Shiqan / Cristiano3120, MIT license).
"""

import ctypes
import datetime as dt
import io
import json
import locale
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
import urllib.error
import urllib.request
import zipfile
from tkinter import ttk, messagebox

APP_VERSION = "1.0"
LOCAL = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
ROAMING = os.environ.get("APPDATA") or os.path.expanduser("~")
DATA_DIR = os.path.join(ROAMING, "ChestCounter")
DATA_FILE = os.path.join(DATA_DIR, "data.json")
TOOLS = os.path.join(LOCAL, "ChestCounter")
DOTNET_DIR = os.path.join(TOOLS, "dotnet")
DOTNET = os.path.join(DOTNET_DIR, "dotnet.exe")
SRC_DIR = os.path.join(TOOLS, "reader_src")
LOG_FILE = os.path.join(TOOLS, "setup.log")
DEMOS = os.path.join(LOCAL, "FortniteGame", "Saved", "Demos")

REPO_SHA = "59515cf4781e60d2c14ba39d8dcab1d7fb986f17"
REPO_ZIP = f"https://codeload.github.com/Cristiano3120/MoreFortniteReplayDecompression/zip/{REPO_SHA}"
DOTNET_INSTALL = "https://dot.net/v1/dotnet-install.ps1"
READER_VERSION = 7          # bump when the reader code changes so it is rebuilt and every replay is re-read
# Each reader version gets its own folder, so a reader that is still running never blocks the new build.
BIN_DIR = os.path.join(TOOLS, f"reader_v{READER_VERSION}")
READER_DLL = os.path.join(BIN_DIR, "ChestReplayReader.dll")

NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
QUIET_SECONDS = 90          # a replay unchanged for this long is considered finished
READ_TIMEOUT = 600          # seconds allowed to read one replay

BG = "#0d1430"
PANEL = "#16204a"
LINE = "#2a3670"
INK = "#eef1ff"
MUTED = "#9aa5d6"
GOLD = "#f7c948"
SKY = "#5ec8ff"
OK = "#5ee39a"
WARN = "#ffb27a"

# ---------------------------------------------------------------- translations

LANGS = {"en": "English", "es": "Español", "pt": "Português", "fr": "Français", "de": "Deutsch"}

T = {
    "en": {
        "app": "Chest Counter",
        "total": "TOTAL CHESTS",
        "today": "Today: {n}",
        "last": "Last match ({time}): {n}",
        "last_split": "Last match ({time}): {n}  ·  {o} opened, {d} destroyed",
        "correction": "Manual correction",
        "matches": "Matches",
        "folder": "Replays folder",
        "settings": "Settings",
        "last14": "Last 14 days",
        "per_day": "Chests per day",
        "col_day": "DAY",
        "col_chests": "CHESTS",
        "stats": "Days played: {d}   ·   Daily average: {a}   ·   Best day: {b} ({date})",
        "no_stats": "No chests counted yet.",
        "st_starting": "Starting",
        "st_preparing": "Setting up",
        "st_error": "Error",
        "st_noreplays": "No replays",
        "st_learning": "Learning",
        "st_reading": "Reading",
        "st_watching": "Watching",
        "i_dotnet": "Downloading .NET 10 (about 200 MB, first time only)…",
        "i_reader": "Downloading the replay reader…",
        "i_build": "Building the replay reader (1–3 minutes)…",
        "i_noreplays": "No replays found. In Fortnite turn on Settings > Game > Replays > Record Replays (Battle Royale). "
                       "Your chests are counted after each match.",
        "i_learning": "Found {n} new chest types. Re-reading your matches…",
        "i_reading": "Reading replays… {done}/{total}",
        "i_reread": "Totals can go down while matches are re-read by a newer reader.",
        "i_watching": "{n} matches counted. New matches are added about 2 minutes after they end.",
        "details": "Details",
        "e_dotnet": "Could not install .NET.",
        "e_build": "Building the replay reader failed.",
        "e_reader": "The replay reader stopped unexpectedly.",
        "e_network": "Could not download the files it needs. Check your internet connection; it will retry by itself.",
        "e_timeout": "Reading took too long",
        "e_noreply": "No response from the reader",
        "autodelete": "Delete counted replays after",
        "days_never": "days (0 = never)",
        "clean_off": "Replays are never deleted.",
        "clean_on": "Counted replays are deleted {n} day(s) after the match. Replays with errors are kept.",
        "clean_done": "Deleted so far: {n} ({mb} MB freed)",
        "set_title": "Settings",
        "language": "Language",
        "count_destroyed": "Count destroyed chests (broken with the pickaxe or explosives)",
        "open_data": "Open data folder",
        "close": "Close",
        "m_title": "Matches read",
        "c_match": "MATCH",
        "c_total": "CHESTS",
        "c_opened": "OPENED",
        "c_destroyed": "DESTROYED",
        "c_status": "STATUS",
        "s_ok": "OK",
        "s_err": "Error: {e}",
        "s_norec": "Warning: recording player not found",
        "s_pending": "Waiting to be read",
        "types": "Chest types learned",
        "nofolder": "The Fortnite replays folder does not exist yet.\n\nIn Fortnite turn on: Settings > Game > Replays > "
                    "Record Replays (Battle Royale), then play a match.",
        "help": "How to use",
        "h1_t": "1. Turn on replays in Fortnite",
        "h1": "Settings > Game > Replays > Record Replays (Battle Royale) = On. The app reads these replays, so without this setting it has nothing to count.",
        "h2_t": "2. Keep the app open and play",
        "h2": "Leave Chest Counter running (minimized is fine). About 2 minutes after each match ends, its chests are added to the total and to today. \"Play again\" from spectator mode works too.",
        "h3_t": "3. What is counted",
        "h3": "Every chest you open (normal, rare, spirit…) and, if enabled in Settings, the chests you break open. Chests opened by other players are not counted.",
        "h4_t": "Buttons",
        "h4": "Matches: every match read and its chests.\nReplays folder: where Fortnite saves your replays.\nSettings: language, destroyed chests and automatic deletion of old replays.\nManual correction: adds or removes chests for today.",
        "h5_t": "Tips",
        "h5": "The first start downloads and builds the replay reader (2–5 minutes). Replays take disk space: use \"Delete counted replays after\" in Settings. If something fails, the Details button opens the log.",
        "days": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
        "months": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        "today_short": "Today",
        "date_fmt": "{wd} {mon} {d}, {y}",
        "thousands": ",",
        "decimal": ".",
    },
    "es": {
        "app": "Contador de Cofres",
        "total": "COFRES EN TOTAL",
        "today": "Hoy: {n}",
        "last": "Última partida ({time}): {n}",
        "last_split": "Última partida ({time}): {n}  ·  {o} abiertos, {d} destruidos",
        "correction": "Corrección manual",
        "matches": "Partidas",
        "folder": "Carpeta de repeticiones",
        "settings": "Ajustes",
        "last14": "Últimos 14 días",
        "per_day": "Cofres por día",
        "col_day": "DÍA",
        "col_chests": "COFRES",
        "stats": "Días jugados: {d}   ·   Media diaria: {a}   ·   Mejor día: {b} ({date})",
        "no_stats": "Aún no hay cofres contados.",
        "st_starting": "Iniciando",
        "st_preparing": "Preparando",
        "st_error": "Error",
        "st_noreplays": "Sin repeticiones",
        "st_learning": "Aprendiendo",
        "st_reading": "Leyendo",
        "st_watching": "Vigilando",
        "i_dotnet": "Descargando .NET 10 (unos 200 MB, solo la primera vez)…",
        "i_reader": "Descargando el lector de repeticiones…",
        "i_build": "Compilando el lector de repeticiones (1–3 minutos)…",
        "i_noreplays": "No hay repeticiones. En Fortnite activa Ajustes > Juego > Repeticiones > Grabar repeticiones "
                       "(Battle Royale). Tus cofres se cuentan al terminar cada partida.",
        "i_learning": "Encontrados {n} tipos de cofre nuevos. Releyendo tus partidas…",
        "i_reading": "Leyendo repeticiones… {done}/{total}",
        "i_reread": "El total puede bajar mientras un lector más nuevo relee las partidas.",
        "i_watching": "{n} partidas contadas. Las nuevas se suman unos 2 minutos después de terminar.",
        "details": "Detalles",
        "e_dotnet": "No se pudo instalar .NET.",
        "e_build": "Falló la compilación del lector de repeticiones.",
        "e_reader": "El lector de repeticiones se cerró inesperadamente.",
        "e_network": "No se pudieron descargar los archivos necesarios. Revisa tu conexión a internet; se reintentará solo.",
        "e_timeout": "La lectura tardó demasiado",
        "e_noreply": "El lector no respondió",
        "autodelete": "Borrar repeticiones ya contadas tras",
        "days_never": "días (0 = nunca)",
        "clean_off": "Las repeticiones no se borran.",
        "clean_on": "Las repeticiones contadas se borran {n} día(s) después de la partida. Las que den error se conservan.",
        "clean_done": "Borradas hasta ahora: {n} ({mb} MB liberados)",
        "set_title": "Ajustes",
        "language": "Idioma",
        "count_destroyed": "Contar cofres destruidos (rotos con el pico o con explosivos)",
        "open_data": "Abrir carpeta de datos",
        "close": "Cerrar",
        "m_title": "Partidas leídas",
        "c_match": "PARTIDA",
        "c_total": "COFRES",
        "c_opened": "ABIERTOS",
        "c_destroyed": "DESTRUIDOS",
        "c_status": "ESTADO",
        "s_ok": "OK",
        "s_err": "Error: {e}",
        "s_norec": "Aviso: no se encontró al jugador que grabó",
        "s_pending": "Pendiente de leer",
        "types": "Tipos de cofre aprendidos",
        "nofolder": "Todavía no existe la carpeta de repeticiones de Fortnite.\n\nEn Fortnite activa: Ajustes > Juego > "
                    "Repeticiones > Grabar repeticiones (Battle Royale) y juega una partida.",
        "help": "Cómo se usa",
        "h1_t": "1. Activa las repeticiones en Fortnite",
        "h1": "Ajustes > Juego > Repeticiones > Grabar repeticiones (Battle Royale) = Activado. La app lee esas repeticiones, así que sin este ajuste no tiene nada que contar.",
        "h2_t": "2. Deja la app abierta y juega",
        "h2": "Deja el Contador de Cofres abierto (puede estar minimizado). Unos 2 minutos después de cada partida, sus cofres se suman al total y al día de hoy. También funciona con \"Volver a jugar\" desde el modo espectador.",
        "h3_t": "3. Qué se cuenta",
        "h3": "Cada cofre que abres (normal, raro, de espíritu…) y, si está activado en Ajustes, los cofres que rompes. Los cofres que abren otros jugadores no se cuentan.",
        "h4_t": "Botones",
        "h4": "Partidas: cada partida leída y sus cofres.\nCarpeta de repeticiones: donde Fortnite guarda tus repeticiones.\nAjustes: idioma, cofres destruidos y borrado automático de repeticiones antiguas.\nCorrección manual: suma o resta cofres al día de hoy.",
        "h5_t": "Consejos",
        "h5": "La primera vez descarga y compila el lector de repeticiones (2–5 minutos). Las repeticiones ocupan espacio: usa \"Borrar repeticiones ya contadas tras\" en Ajustes. Si algo falla, el botón Detalles abre el registro.",
        "days": ["lun", "mar", "mié", "jue", "vie", "sáb", "dom"],
        "months": ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"],
        "today_short": "Hoy",
        "date_fmt": "{wd} {d} {mon} {y}",
        "thousands": ".",
        "decimal": ",",
    },
    "pt": {
        "app": "Contador de Baús",
        "total": "BAÚS NO TOTAL",
        "today": "Hoje: {n}",
        "last": "Última partida ({time}): {n}",
        "last_split": "Última partida ({time}): {n}  ·  {o} abertos, {d} destruídos",
        "correction": "Correção manual",
        "matches": "Partidas",
        "folder": "Pasta de replays",
        "settings": "Configurações",
        "last14": "Últimos 14 dias",
        "per_day": "Baús por dia",
        "col_day": "DIA",
        "col_chests": "BAÚS",
        "stats": "Dias jogados: {d}   ·   Média diária: {a}   ·   Melhor dia: {b} ({date})",
        "no_stats": "Nenhum baú contado ainda.",
        "st_starting": "Iniciando",
        "st_preparing": "Preparando",
        "st_error": "Erro",
        "st_noreplays": "Sem replays",
        "st_learning": "Aprendendo",
        "st_reading": "Lendo",
        "st_watching": "Monitorando",
        "i_dotnet": "Baixando o .NET 10 (cerca de 200 MB, só na primeira vez)…",
        "i_reader": "Baixando o leitor de replays…",
        "i_build": "Compilando o leitor de replays (1–3 minutos)…",
        "i_noreplays": "Nenhum replay encontrado. No Fortnite ative Configurações > Jogo > Replays > Gravar replays "
                       "(Battle Royale). Seus baús são contados ao fim de cada partida.",
        "i_learning": "{n} novos tipos de baú encontrados. Relendo suas partidas…",
        "i_reading": "Lendo replays… {done}/{total}",
        "i_reread": "O total pode diminuir enquanto um leitor mais novo relê as partidas.",
        "i_watching": "{n} partidas contadas. As novas são somadas cerca de 2 minutos após terminarem.",
        "details": "Detalhes",
        "e_dotnet": "Não foi possível instalar o .NET.",
        "e_build": "Falha ao compilar o leitor de replays.",
        "e_reader": "O leitor de replays fechou inesperadamente.",
        "e_network": "Não foi possível baixar os arquivos necessários. Verifique sua conexão; ele tentará de novo sozinho.",
        "e_timeout": "A leitura demorou demais",
        "e_noreply": "O leitor não respondeu",
        "autodelete": "Apagar replays já contados após",
        "days_never": "dias (0 = nunca)",
        "clean_off": "Os replays nunca são apagados.",
        "clean_on": "Os replays contados são apagados {n} dia(s) após a partida. Os que derem erro são mantidos.",
        "clean_done": "Apagados até agora: {n} ({mb} MB liberados)",
        "set_title": "Configurações",
        "language": "Idioma",
        "count_destroyed": "Contar baús destruídos (quebrados com a picareta ou explosivos)",
        "open_data": "Abrir pasta de dados",
        "close": "Fechar",
        "m_title": "Partidas lidas",
        "c_match": "PARTIDA",
        "c_total": "BAÚS",
        "c_opened": "ABERTOS",
        "c_destroyed": "DESTRUÍDOS",
        "c_status": "ESTADO",
        "s_ok": "OK",
        "s_err": "Erro: {e}",
        "s_norec": "Aviso: jogador que gravou não encontrado",
        "s_pending": "Aguardando leitura",
        "types": "Tipos de baú aprendidos",
        "nofolder": "A pasta de replays do Fortnite ainda não existe.\n\nNo Fortnite ative: Configurações > Jogo > "
                    "Replays > Gravar replays (Battle Royale) e jogue uma partida.",
        "help": "Como usar",
        "h1_t": "1. Ative os replays no Fortnite",
        "h1": "Configurações > Jogo > Replays > Gravar replays (Battle Royale) = Ativado. O app lê esses replays; sem essa opção não há nada para contar.",
        "h2_t": "2. Deixe o app aberto e jogue",
        "h2": "Deixe o Contador de Baús aberto (pode ficar minimizado). Cerca de 2 minutos após cada partida, os baús são somados ao total e ao dia de hoje. \"Jogar novamente\" no modo espectador também funciona.",
        "h3_t": "3. O que é contado",
        "h3": "Cada baú que você abre (normal, raro, espiritual…) e, se ativado nas Configurações, os baús que você quebra. Baús abertos por outros jogadores não contam.",
        "h4_t": "Botões",
        "h4": "Partidas: cada partida lida e seus baús.\nPasta de replays: onde o Fortnite salva seus replays.\nConfigurações: idioma, baús destruídos e exclusão automática de replays antigos.\nCorreção manual: soma ou subtrai baús do dia de hoje.",
        "h5_t": "Dicas",
        "h5": "Na primeira vez ele baixa e compila o leitor de replays (2–5 minutos). Replays ocupam espaço: use \"Apagar replays já contados após\" nas Configurações. Se algo falhar, o botão Detalhes abre o registro.",
        "days": ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"],
        "months": ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"],
        "today_short": "Hoje",
        "date_fmt": "{wd} {d} {mon} {y}",
        "thousands": ".",
        "decimal": ",",
    },
    "fr": {
        "app": "Compteur de Coffres",
        "total": "COFFRES AU TOTAL",
        "today": "Aujourd'hui : {n}",
        "last": "Dernière partie ({time}) : {n}",
        "last_split": "Dernière partie ({time}) : {n}  ·  {o} ouverts, {d} détruits",
        "correction": "Correction manuelle",
        "matches": "Parties",
        "folder": "Dossier des replays",
        "settings": "Paramètres",
        "last14": "14 derniers jours",
        "per_day": "Coffres par jour",
        "col_day": "JOUR",
        "col_chests": "COFFRES",
        "stats": "Jours joués : {d}   ·   Moyenne par jour : {a}   ·   Meilleur jour : {b} ({date})",
        "no_stats": "Aucun coffre compté pour l'instant.",
        "st_starting": "Démarrage",
        "st_preparing": "Préparation",
        "st_error": "Erreur",
        "st_noreplays": "Aucun replay",
        "st_learning": "Apprentissage",
        "st_reading": "Lecture",
        "st_watching": "En veille",
        "i_dotnet": "Téléchargement de .NET 10 (environ 200 Mo, la première fois seulement)…",
        "i_reader": "Téléchargement du lecteur de replays…",
        "i_build": "Compilation du lecteur de replays (1 à 3 minutes)…",
        "i_noreplays": "Aucun replay trouvé. Dans Fortnite, activez Paramètres > Jeu > Replays > Enregistrer les replays "
                       "(Battle Royale). Vos coffres sont comptés après chaque partie.",
        "i_learning": "{n} nouveaux types de coffre trouvés. Relecture de vos parties…",
        "i_reading": "Lecture des replays… {done}/{total}",
        "i_reread": "Le total peut baisser pendant qu'un lecteur plus récent relit les parties.",
        "i_watching": "{n} parties comptées. Les nouvelles sont ajoutées environ 2 minutes après la fin.",
        "details": "Détails",
        "e_dotnet": "Impossible d'installer .NET.",
        "e_build": "La compilation du lecteur de replays a échoué.",
        "e_reader": "Le lecteur de replays s'est arrêté de façon inattendue.",
        "e_network": "Impossible de télécharger les fichiers nécessaires. Vérifiez votre connexion ; nouvel essai automatique.",
        "e_timeout": "La lecture a pris trop de temps",
        "e_noreply": "Le lecteur n'a pas répondu",
        "autodelete": "Supprimer les replays comptés après",
        "days_never": "jours (0 = jamais)",
        "clean_off": "Les replays ne sont jamais supprimés.",
        "clean_on": "Les replays comptés sont supprimés {n} jour(s) après la partie. Ceux en erreur sont conservés.",
        "clean_done": "Supprimés jusqu'ici : {n} ({mb} Mo libérés)",
        "set_title": "Paramètres",
        "language": "Langue",
        "count_destroyed": "Compter les coffres détruits (cassés à la pioche ou aux explosifs)",
        "open_data": "Ouvrir le dossier des données",
        "close": "Fermer",
        "m_title": "Parties lues",
        "c_match": "PARTIE",
        "c_total": "COFFRES",
        "c_opened": "OUVERTS",
        "c_destroyed": "DÉTRUITS",
        "c_status": "ÉTAT",
        "s_ok": "OK",
        "s_err": "Erreur : {e}",
        "s_norec": "Attention : joueur enregistré introuvable",
        "s_pending": "En attente de lecture",
        "types": "Types de coffre appris",
        "nofolder": "Le dossier des replays de Fortnite n'existe pas encore.\n\nDans Fortnite, activez : Paramètres > Jeu > "
                    "Replays > Enregistrer les replays (Battle Royale), puis jouez une partie.",
        "help": "Mode d'emploi",
        "h1_t": "1. Activez les replays dans Fortnite",
        "h1": "Paramètres > Jeu > Replays > Enregistrer les replays (Battle Royale) = Activé. L'application lit ces replays : sans ce réglage, elle n'a rien à compter.",
        "h2_t": "2. Laissez l'application ouverte et jouez",
        "h2": "Laissez le Compteur de Coffres ouvert (même réduit). Environ 2 minutes après chaque partie, ses coffres s'ajoutent au total et à aujourd'hui. « Rejouer » depuis le mode spectateur fonctionne aussi.",
        "h3_t": "3. Ce qui est compté",
        "h3": "Chaque coffre que vous ouvrez (normal, rare, spirituel…) et, si c'est activé dans les Paramètres, les coffres que vous cassez. Les coffres ouverts par d'autres joueurs ne comptent pas.",
        "h4_t": "Boutons",
        "h4": "Parties : chaque partie lue et ses coffres.\nDossier des replays : là où Fortnite enregistre vos replays.\nParamètres : langue, coffres détruits et suppression automatique des anciens replays.\nCorrection manuelle : ajoute ou retire des coffres à aujourd'hui.",
        "h5_t": "Conseils",
        "h5": "Au premier démarrage, le lecteur de replays est téléchargé et compilé (2 à 5 minutes). Les replays prennent de la place : utilisez « Supprimer les replays comptés après » dans les Paramètres. En cas de problème, le bouton Détails ouvre le journal.",
        "days": ["lun.", "mar.", "mer.", "jeu.", "ven.", "sam.", "dim."],
        "months": ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."],
        "today_short": "Auj.",
        "date_fmt": "{wd} {d} {mon} {y}",
        "thousands": " ",
        "decimal": ",",
    },
    "de": {
        "app": "Truhenzähler",
        "total": "TRUHEN INSGESAMT",
        "today": "Heute: {n}",
        "last": "Letztes Match ({time}): {n}",
        "last_split": "Letztes Match ({time}): {n}  ·  {o} geöffnet, {d} zerstört",
        "correction": "Manuelle Korrektur",
        "matches": "Matches",
        "folder": "Replay-Ordner",
        "settings": "Einstellungen",
        "last14": "Letzte 14 Tage",
        "per_day": "Truhen pro Tag",
        "col_day": "TAG",
        "col_chests": "TRUHEN",
        "stats": "Gespielte Tage: {d}   ·   Tagesschnitt: {a}   ·   Bester Tag: {b} ({date})",
        "no_stats": "Noch keine Truhen gezählt.",
        "st_starting": "Startet",
        "st_preparing": "Einrichtung",
        "st_error": "Fehler",
        "st_noreplays": "Keine Replays",
        "st_learning": "Lernt",
        "st_reading": "Liest",
        "st_watching": "Bereit",
        "i_dotnet": ".NET 10 wird heruntergeladen (ca. 200 MB, nur beim ersten Mal)…",
        "i_reader": "Replay-Leser wird heruntergeladen…",
        "i_build": "Replay-Leser wird kompiliert (1–3 Minuten)…",
        "i_noreplays": "Keine Replays gefunden. Aktiviere in Fortnite Einstellungen > Spiel > Replays > Replays aufzeichnen "
                       "(Battle Royale). Deine Truhen werden nach jedem Match gezählt.",
        "i_learning": "{n} neue Truhentypen gefunden. Deine Matches werden neu gelesen…",
        "i_reading": "Replays werden gelesen… {done}/{total}",
        "i_reread": "Die Summe kann sinken, während ein neuerer Leser die Matches neu liest.",
        "i_watching": "{n} Matches gezählt. Neue Matches kommen etwa 2 Minuten nach dem Ende dazu.",
        "details": "Details",
        "e_dotnet": ".NET konnte nicht installiert werden.",
        "e_build": "Der Replay-Leser konnte nicht kompiliert werden.",
        "e_reader": "Der Replay-Leser wurde unerwartet beendet.",
        "e_network": "Benötigte Dateien konnten nicht geladen werden. Prüfe deine Internetverbindung; es wird erneut versucht.",
        "e_timeout": "Lesen hat zu lange gedauert",
        "e_noreply": "Keine Antwort vom Leser",
        "autodelete": "Gezählte Replays löschen nach",
        "days_never": "Tagen (0 = nie)",
        "clean_off": "Replays werden nie gelöscht.",
        "clean_on": "Gezählte Replays werden {n} Tag(e) nach dem Match gelöscht. Replays mit Fehlern bleiben erhalten.",
        "clean_done": "Bisher gelöscht: {n} ({mb} MB frei)",
        "set_title": "Einstellungen",
        "language": "Sprache",
        "count_destroyed": "Zerstörte Truhen zählen (mit Spitzhacke oder Sprengstoff)",
        "open_data": "Datenordner öffnen",
        "close": "Schließen",
        "m_title": "Gelesene Matches",
        "c_match": "MATCH",
        "c_total": "TRUHEN",
        "c_opened": "GEÖFFNET",
        "c_destroyed": "ZERSTÖRT",
        "c_status": "STATUS",
        "s_ok": "OK",
        "s_err": "Fehler: {e}",
        "s_norec": "Hinweis: aufnehmender Spieler nicht gefunden",
        "s_pending": "Wartet auf Lesen",
        "types": "Gelernte Truhentypen",
        "nofolder": "Der Fortnite-Replay-Ordner existiert noch nicht.\n\nAktiviere in Fortnite: Einstellungen > Spiel > "
                    "Replays > Replays aufzeichnen (Battle Royale) und spiele ein Match.",
        "help": "Anleitung",
        "h1_t": "1. Replays in Fortnite aktivieren",
        "h1": "Einstellungen > Spiel > Replays > Replays aufzeichnen (Battle Royale) = An. Die App liest diese Replays – ohne diese Einstellung gibt es nichts zu zählen.",
        "h2_t": "2. App offen lassen und spielen",
        "h2": "Lass den Truhenzähler laufen (minimiert genügt). Etwa 2 Minuten nach jedem Match werden seine Truhen zur Summe und zu heute addiert. „Erneut spielen“ aus dem Zuschauermodus funktioniert auch.",
        "h3_t": "3. Was gezählt wird",
        "h3": "Jede Truhe, die du öffnest (normal, selten, Geister…) und – wenn in den Einstellungen aktiviert – Truhen, die du zerstörst. Von anderen Spielern geöffnete Truhen zählen nicht.",
        "h4_t": "Schaltflächen",
        "h4": "Matches: jedes gelesene Match mit seinen Truhen.\nReplay-Ordner: wo Fortnite deine Replays speichert.\nEinstellungen: Sprache, zerstörte Truhen und automatisches Löschen alter Replays.\nManuelle Korrektur: fügt heute Truhen hinzu oder zieht welche ab.",
        "h5_t": "Tipps",
        "h5": "Beim ersten Start wird der Replay-Leser geladen und kompiliert (2–5 Minuten). Replays brauchen Speicherplatz: nutze „Gezählte Replays löschen nach“ in den Einstellungen. Wenn etwas schiefgeht, öffnet „Details“ das Protokoll.",
        "days": ["Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa.", "So."],
        "months": ["Jan.", "Feb.", "März", "Apr.", "Mai", "Juni", "Juli", "Aug.", "Sep.", "Okt.", "Nov.", "Dez."],
        "today_short": "Heute",
        "date_fmt": "{wd} {d}. {mon} {y}",
        "thousands": ".",
        "decimal": ",",
    },
}

_lang = "en"


def detect_language():
    """Windows display language, falling back to the system locale."""
    code = ""
    try:
        if sys.platform == "win32":
            lcid = ctypes.windll.kernel32.GetUserDefaultUILanguage()
            code = locale.windows_locale.get(lcid, "")
    except Exception:
        pass
    if not code:
        try:
            code = locale.getlocale()[0] or ""
        except Exception:
            code = ""
    code = code.lower()[:2]
    return code if code in T else "en"


def set_language(code):
    global _lang
    _lang = code if code in T else "en"


def tr(key, **kw):
    s = T[_lang].get(key, T["en"][key])
    return s.format(**kw) if kw else s


def fmt_int(n):
    return f"{n:,}".replace(",", T[_lang]["thousands"])


def fmt_dec(x):
    return f"{x:.1f}".replace(".", T[_lang]["decimal"])


def fmt_date(d):
    L = T[_lang]
    return L["date_fmt"].format(wd=L["days"][d.weekday()], d=d.day, mon=L["months"][d.month - 1], y=d.year)


# ---------------------------------------------------------------- replay reader (C#, built on first run)

CSPROJ = """<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <AssemblyName>ChestReplayReader</AssemblyName>
    <RootNamespace>ChestReplayReader</RootNamespace>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
    <NoWarn>$(NoWarn);CS8632;CS8618;CS8600;CS8602;CS8604</NoWarn>
    <InvariantGlobalization>true</InvariantGlobalization>
  </PropertyGroup>
  <ItemGroup>
    <ProjectReference Include="..\\FortniteReplayReader\\FortniteReplayReader.csproj" />
  </ItemGroup>
</Project>
"""

PROGRAM_CS = r'''// Reads Fortnite replays (.replay) and counts the chests looted by the player who recorded the match.
//  - Opened chests: the game replicates on every chest who opened it (SearchingPawn). When missing, the moment each
//    player started searching (bStartedInteractSearch) is used.
//  - Destroyed chests: credited to the last recorded hit or, failing that, to the player closest to the chest.
//  - A chest only counts if your character was next to it.
//  - One chest made of several actors in the same spot (spirit/relic chests) counts once.
//  - Chest types come from a text file (one per line); the app learns new ones by itself.
using System.Reflection;
using System.Reflection.Emit;
using System.Text.Json;
using FortniteReplayReader;
using FortniteReplayReader.Models.NetFieldExports;
using FortniteReplayReader.Models.NetFieldExports.RPC;
using Unreal.Core.Attributes;
using Unreal.Core.Contracts;
using Unreal.Core.Models;
using Unreal.Core.Models.Enums;

namespace ChestReplayReader;

public class Cofre : INetFieldExportGroup
{
    [NetFieldExport("bAlreadySearched", RepLayoutCmdType.PropertyBool)]
    public bool? bAlreadySearched { get; set; }

    [NetFieldExport("SearchingPawn", RepLayoutCmdType.PropertyObject)]
    public uint? SearchingPawn { get; set; }

    [NetFieldExport("ReplicatedLootTier", RepLayoutCmdType.PropertyInt)]
    public int? ReplicatedLootTier { get; set; }

    [NetFieldExport("bDestroyed", RepLayoutCmdType.PropertyBool)]
    public bool? bDestroyed { get; set; }

    [NetFieldExport("Health", RepLayoutCmdType.PropertyUInt16)]
    public ushort? Health { get; set; }
}

public class InfoCofre
{
    public uint Actor { get; set; }
    public string Tipo { get; set; } = "";
    public uint UltimoPawn { get; set; }
    public uint PawnAlAbrir { get; set; }
    public bool Abierto { get; set; }
    public bool Destruido { get; set; }
    public float TAbierto { get; set; } = -1;
    public float TDestruido { get; set; } = -1;
    public uint PawnBusqueda { get; set; }          // SearchingPawn visto en el momento de abrirse
    public uint UltimoGolpe { get; set; }
    public float SegundoGolpe { get; set; } = -999;
    public float Segundo { get; set; }
    public string Metodo { get; set; } = "";
    public double[]? Loc { get; set; }
    public string LocFuente { get; set; } = "";
    public double DistMia { get; set; } = -1;
    public bool Duplicado { get; set; }
    public bool CuentaComoDestruido { get; set; }
    public bool Lejos { get; set; }
}

public class LectorCofres : ReplayReader
{
    public LectorCofres() : base(null, ParseMode.Full) { }

    private readonly Dictionary<uint, uint> _canalActor = new();
    private readonly Dictionary<uint, (float T, double[] L)> _aparicion = new();
    public readonly Dictionary<uint, uint> PawnAEstado = new();
    public readonly Dictionary<uint, int> EstadoAEquipo = new();
    public readonly Dictionary<uint, int> EstadoAId = new();
    public readonly Dictionary<uint, InfoCofre> Cofres = new();
    public readonly List<(uint Pawn, float T)> Busquedas = new();
    public readonly List<(uint Pawn, float T)> Golpes = new();        // cualquier golpe a algo que no es un jugador
    public readonly Dictionary<uint, List<(float T, double X, double Y, double Z)>> Posiciones = new();
    public readonly List<(float T, double[] L)> Botin = new();         // objetos que aparecen en el suelo
    private readonly HashSet<uint> _botinVisto = new();
    public int GolpesTotal, GolpesACofre;
    public readonly HashSet<string> Grupos = new();
    public uint? Grabador;

    protected override void Cleanup()
    {
        foreach (var k in _netGuidCache.NetFieldExportGroupMap.Keys)
        {
            Grupos.Add(k);
        }
        base.Cleanup();
    }

    protected override void OnChannelOpened(uint channelIndex, NetworkGUID? actor)
    {
        base.OnChannelOpened(channelIndex, actor);
        if (actor != null)
        {
            _canalActor[channelIndex] = actor.Value;
            try
            {
                var loc = Channels[channelIndex]?.Actor?.Location;
                if (loc != null && (loc.X != 0 || loc.Y != 0 || loc.Z != 0))
                {
                    _aparicion[actor.Value] = (CurrentTimeSeconds, new[] { loc.X, loc.Y, loc.Z });
                }
            }
            catch
            {
                // sin ubicación
            }
        }
    }

    private void GuardarPos(uint pawn, double x, double y, double z)
    {
        if (x == 0 && y == 0 && z == 0) return;
        if (!Posiciones.TryGetValue(pawn, out var l))
        {
            l = new List<(float, double, double, double)>();
            Posiciones[pawn] = l;
        }
        l.Add((CurrentTimeSeconds, x, y, z));
    }

    /// <summary>Última posición conocida del personaje en el segundo t (como mucho 5 s de antigüedad).</summary>
    public double[]? Pos(uint pawn, float t)
    {
        if (!Posiciones.TryGetValue(pawn, out var l)) return null;
        for (var i = l.Count - 1; i >= 0; i--)
        {
            if (l[i].T <= t + 0.3f)
            {
                return l[i].T >= t - 5f ? new[] { l[i].X, l[i].Y, l[i].Z } : null;
            }
        }
        return null;
    }

    public static double Dist(double[] a, double[] b)
    {
        var dx = a[0] - b[0];
        var dy = a[1] - b[1];
        var dz = a[2] - b[2];
        return Math.Sqrt(dx * dx + dy * dy + dz * dz);
    }

    private InfoCofre Info(uint id, Cofre c)
    {
        if (!Cofres.TryGetValue(id, out var info))
        {
            var ruta = c.GetType().GetCustomAttribute<NetFieldExportGroupAttribute>()?.Path ?? c.GetType().Name;
            var corto = ruta.Substring(ruta.LastIndexOf('.') + 1);
            info = new InfoCofre { Tipo = corto, Actor = id };
            if (_aparicion.TryGetValue(id, out var ap))
            {
                info.Loc = ap.L;
                info.LocFuente = "actor";
            }
            Cofres[id] = info;
        }
        return info;
    }

    protected override void OnExportRead(uint channelIndex, INetFieldExportGroup? exportGroup)
    {
        base.OnExportRead(channelIndex, exportGroup);
        switch (exportGroup)
        {
            case GameState gs:
                if (gs.RecorderPlayerState != null && gs.RecorderPlayerState.Value > 0)
                {
                    Grabador ??= gs.RecorderPlayerState.Value;
                }
                break;

            case FortPlayerState ps:
                if (_canalActor.TryGetValue(channelIndex, out var est))
                {
                    if (ps.TeamIndex.HasValue)
                    {
                        EstadoAEquipo[est] = ps.TeamIndex.Value;
                    }
                    var pid = ps.PlayerId.HasValue ? (int?)ps.PlayerId.Value : ps.PlayerID;
                    if (pid.HasValue)
                    {
                        EstadoAId[est] = pid.Value;
                    }
                }
                break;

            case PlayerPawn pawn:
                if (_canalActor.TryGetValue(channelIndex, out var pawnId))
                {
                    if (pawn.PlayerState.HasValue)
                    {
                        PawnAEstado[pawnId] = pawn.PlayerState.Value;
                    }
                    if (pawn.bStartedInteractSearch == true)
                    {
                        Busquedas.Add((pawnId, CurrentTimeSeconds));
                    }
                    var mov = pawn.ReplicatedMovement?.Location;
                    if (mov != null)
                    {
                        GuardarPos(pawnId, mov.X, mov.Y, mov.Z);
                    }
                    else if (!Posiciones.ContainsKey(pawnId) && _aparicion.TryGetValue(pawnId, out var apP))
                    {
                        GuardarPos(pawnId, apP.L[0], apP.L[1], apP.L[2]);
                    }
                }
                break;

            case FortPickup pickup:
                if (_canalActor.TryGetValue(channelIndex, out var pk) && _botinVisto.Add(pk))
                {
                    if (_aparicion.TryGetValue(pk, out var apB))
                    {
                        Botin.Add((apB.T, apB.L));
                    }
                    else if (pickup.ReplicatedMovement?.Location is { } lb)
                    {
                        Botin.Add((CurrentTimeSeconds, new[] { lb.X, lb.Y, lb.Z }));
                    }
                }
                break;

            case BatchedDamageCues golpe:
                if (_canalActor.TryGetValue(channelIndex, out var atacante))
                {
                    GolpesTotal++;
                    var objetivo = golpe.NonPlayerHitActor is > 0 ? golpe.NonPlayerHitActor.Value
                                 : golpe.HitActor is > 0 ? golpe.HitActor.Value : 0u;
                    if (golpe.NonPlayerHitActor is > 0 || golpe.NonPlayerMagnitude is > 0)
                    {
                        Golpes.Add((atacante, CurrentTimeSeconds));
                    }
                    if (objetivo != 0 && Cofres.TryGetValue(objetivo, out var golpeado))
                    {
                        GolpesACofre++;
                        golpeado.UltimoGolpe = atacante;
                        golpeado.SegundoGolpe = CurrentTimeSeconds;
                    }
                }
                break;

            case Cofre c:
                if (!_canalActor.TryGetValue(channelIndex, out var id))
                {
                    return;
                }
                var info = Info(id, c);
                if (c.SearchingPawn.HasValue && c.SearchingPawn.Value != 0)
                {
                    info.UltimoPawn = c.SearchingPawn.Value;
                }
                if (c.bAlreadySearched == true && !info.Abierto)
                {
                    info.Abierto = true;
                    info.TAbierto = CurrentTimeSeconds;
                    info.PawnBusqueda = info.UltimoPawn;
                }
                if (c.bDestroyed == true && !info.Destruido)
                {
                    info.Destruido = true;
                    info.TDestruido = CurrentTimeSeconds;
                }
                break;
        }
    }

    /// <summary>Ubicación del cofre: la del actor o, si no se conoce, la del botín que salió de él.</summary>
    private void Ubicar(InfoCofre c)
    {
        if (c.Loc != null) return;
        var t = c.Segundo;
        var cerca = Botin.Where(b => b.T >= t - 0.5f && b.T <= t + 1.5f).OrderBy(b => b.T).ToList();
        if (cerca.Count == 0) return;
        var primero = cerca[0].L;
        var grupo = cerca.Where(b => Dist(b.L, primero) < 400).ToList();
        c.Loc = new[] { grupo.Average(b => b.L[0]), grupo.Average(b => b.L[1]), grupo.Average(b => b.L[2]) };
        c.LocFuente = "botin";
    }

    /// <summary>El personaje más cercano al cofre en ese momento (solo si está a menos de maxDist).</summary>
    private uint MasCercano(InfoCofre c, double maxDist)
    {
        if (c.Loc == null) return 0;
        uint mejor = 0;
        var dMejor = maxDist;
        foreach (var p in Posiciones.Keys)
        {
            var pos = Pos(p, c.Segundo);
            if (pos == null) continue;
            var d = Dist(pos, c.Loc);
            if (d < dMejor)
            {
                dMejor = d;
                mejor = p;
            }
        }
        return mejor;
    }

    private const double MaxDistAbrir = 1000;   // 10 m (en el juego, 1 unidad = 1 cm)
    private const double MaxDistRomper = 800;   // 8 m

    public bool EsMiPawn(uint pawn) =>
        Grabador.HasValue && PawnAEstado.TryGetValue(pawn, out var e) && e == Grabador.Value;

    public void Resolver()
    {
        // 1) Clasificar cada cofre: abierto por alguien conocido, destruido o abierto sin autor.
        foreach (var c in Cofres.Values)
        {
            if (c.Abierto && c.PawnBusqueda != 0)
            {
                c.PawnAlAbrir = c.PawnBusqueda;
                c.Metodo = "autor";
                c.Segundo = c.TAbierto;
            }
            else if (c.Destruido && (!c.Abierto || Math.Abs(c.TDestruido - c.TAbierto) < 3f))
            {
                c.CuentaComoDestruido = true;
                c.Segundo = c.Abierto ? Math.Min(c.TAbierto, c.TDestruido) : c.TDestruido;
            }
            else if (c.Abierto)
            {
                c.Segundo = c.TAbierto;
            }
        }

        // 2) Abiertos sin autor: quien empezó a buscar justo antes (cada búsqueda explica un solo cofre).
        var usadas = new HashSet<int>();
        foreach (var c in Cofres.Values.Where(x => x.Metodo == "autor"))
        {
            for (var i = Busquedas.Count - 1; i >= 0; i--)
            {
                var bq = Busquedas[i];
                if (!usadas.Contains(i) && bq.Pawn == c.PawnAlAbrir && bq.T <= c.Segundo + 0.3f && bq.T >= c.Segundo - 3.5f)
                {
                    usadas.Add(i);
                    break;
                }
            }
        }
        foreach (var c in Cofres.Values.Where(x => x.Abierto && !x.CuentaComoDestruido && x.PawnAlAbrir == 0).OrderBy(x => x.Segundo))
        {
            var mejor = -1;
            for (var i = 0; i < Busquedas.Count; i++)
            {
                var b = Busquedas[i];
                if (usadas.Contains(i) || b.T > c.Segundo + 0.3f || b.T < c.Segundo - 3.5f) continue;
                if (mejor < 0 || b.T > Busquedas[mejor].T) mejor = i;
            }
            if (mejor >= 0)
            {
                usadas.Add(mejor);
                c.PawnAlAbrir = Busquedas[mejor].Pawn;
                c.Metodo = "busqueda";
            }
        }

        // 3) Ubicaciones y distancia a mi personaje.
        var misPawns = Posiciones.Keys.Where(EsMiPawn).ToList();
        foreach (var c in Cofres.Values.Where(x => x.Abierto || x.Destruido))
        {
            Ubicar(c);
            if (c.Loc != null)
            {
                foreach (var p in misPawns)
                {
                    var pos = Pos(p, c.Segundo);
                    if (pos == null) continue;
                    var d = Dist(pos, c.Loc);
                    if (c.DistMia < 0 || d < c.DistMia) c.DistMia = d;
                }
            }
        }

        // 3b) Si mi personaje estaba lejos del cofre, no lo abrí yo (p. ej. los cofres de espíritu marcan al jugador
        //     aunque esté a más de 100 m). Abrir exige estar al lado.
        foreach (var c in Cofres.Values.Where(x => x.PawnAlAbrir != 0 && EsMiPawn(x.PawnAlAbrir) && x.DistMia > MaxDistAbrir))
        {
            c.PawnAlAbrir = 0;
            c.Lejos = true;
        }

        // 4) Destruidos (y abiertos que siguen sin autor): golpe registrado o personaje más cercano.
        foreach (var c in Cofres.Values.Where(x => (x.CuentaComoDestruido || x.Abierto) && x.PawnAlAbrir == 0))
        {
            if (c.Lejos) continue;
            if (c.UltimoGolpe != 0 && c.Segundo - c.SegundoGolpe <= 10f && c.Segundo >= c.SegundoGolpe - 0.5f)
            {
                c.PawnAlAbrir = c.UltimoGolpe;
                c.Metodo = "golpe";
                continue;
            }
            // Romper con el pico o abrir exige estar al lado (medido: 1-6 m).
            var cercano = MasCercano(c, MaxDistRomper);
            if (cercano != 0)
            {
                c.PawnAlAbrir = cercano;
                c.Metodo = "cercania";
            }
        }

        // 5) Duplicados: dos actores del mismo cofre (p. ej. cofres de espíritu) cuentan una sola vez.
        var mios = Cofres.Values.Where(x => x.PawnAlAbrir != 0 && EsMiPawn(x.PawnAlAbrir)).OrderBy(x => x.Segundo).ToList();
        for (var i = 0; i < mios.Count; i++)
        {
            if (mios[i].Duplicado) continue;
            for (var j = i + 1; j < mios.Count; j++)
            {
                var a = mios[i];
                var b = mios[j];
                if (b.Duplicado) continue;
                if (b.Segundo - a.Segundo > 10f) break;
                var mismoSitio = a.Loc != null && b.Loc != null && Dist(a.Loc, b.Loc) < 350;
                var mismoTipoYa = a.Loc == null || b.Loc == null
                    ? a.Tipo == b.Tipo && b.Segundo - a.Segundo < 1.5f
                    : false;
                if (mismoSitio || mismoTipoYa)
                {
                    b.Duplicado = true;
                }
            }
        }
    }
}

public static class Program
{
    private static readonly string[] Predeterminados =
    {
        "/Game/Building/ActorBlueprints/Containers/Tiered_Chest_Athena.Tiered_Chest_Athena_C",
        "/Game/Building/ActorBlueprints/Containers/Tiered_Chest_Athena_FactionChest_NoLocks.Tiered_Chest_Athena_FactionChest_NoLocks_C",
    };

    /// <summary>Crea en tiempo de ejecución un tipo de exportación por cada clase de cofre conocida.</summary>
    private static void RegistrarCofres(IEnumerable<string> rutas)
    {
        var ab = AssemblyBuilder.DefineDynamicAssembly(new AssemblyName("DynamicChestReplayReader"), AssemblyBuilderAccess.Run);
        var mb = ab.DefineDynamicModule("Cofres");
        var ctor = typeof(NetFieldExportGroupAttribute).GetConstructor(new[] { typeof(string), typeof(ParseMode) })!;
        var i = 0;
        foreach (var ruta in rutas.Distinct())
        {
            var tb = mb.DefineType("CofreDin" + i++, TypeAttributes.Public | TypeAttributes.Class, typeof(Cofre));
            tb.SetCustomAttribute(new CustomAttributeBuilder(ctor, new object[] { ruta, ParseMode.Minimal }));
            tb.DefineDefaultConstructor(MethodAttributes.Public);
            tb.CreateType();
        }
    }

    private static bool PareceCofre(string g) =>
        g.Contains("Chest", StringComparison.OrdinalIgnoreCase)
        && !g.Contains(':') && !g.Contains("ClassNetCache", StringComparison.OrdinalIgnoreCase)
        && !g.Contains("Ammo", StringComparison.OrdinalIgnoreCase)
        && !g.Contains("Creative", StringComparison.OrdinalIgnoreCase)
        && g.StartsWith("/");

    private static string Linea(LectorCofres l, InfoCofre c)
    {
        var t = (int)c.Segundo;
        var quien = c.PawnAlAbrir == 0 ? "?" : l.EsMiPawn(c.PawnAlAbrir) ? "YO" : "otro";
        var estado = c.CuentaComoDestruido ? "destr" : c.Abierto ? "abierto" : "-";
        if (c.Abierto && c.Destruido) estado += $"(a{c.TAbierto:0.0}/d{c.TDestruido:0.0})";
        return $"{t / 60:00}:{t % 60:00} {c.Tipo.Replace("_C", "")} {estado} {c.Metodo} {quien} " +
               $"loc={(c.LocFuente == "" ? "no" : c.LocFuente)} d={(c.DistMia < 0 ? "?" : ((int)c.DistMia).ToString())} id={c.Actor}" +
               (c.Duplicado ? " DUP" : "") + (c.Lejos ? " LEJOS" : "");
    }

    private static object Analizar(string ruta)
    {
        var lector = new LectorCofres();
        var replay = lector.ReadReplay(ruta);
        lector.Resolver();

        bool EsMio(InfoCofre c) => c.PawnAlAbrir != 0 && lector.EsMiPawn(c.PawnAlAbrir);

        var abiertos = lector.Cofres.Values.Where(c => c.Abierto).ToList();
        var destruidos = lector.Cofres.Values.Where(c => c.Destruido).ToList();
        var mios = lector.Cofres.Values.Where(c => (c.Abierto || c.CuentaComoDestruido) && EsMio(c) && !c.Duplicado).ToList();

        // Detalle: mis cofres, todos los destruidos cercanos y todos los de espíritu.
        var detalle = lector.Cofres.Values
            .Where(c => (c.Abierto || c.Destruido) && (EsMio(c) || c.Duplicado || c.Lejos || c.CuentaComoDestruido && (c.DistMia < 0 || c.DistMia < 5000)
                        || c.Tipo.Contains("Relic", StringComparison.OrdinalIgnoreCase)))
            .OrderBy(c => c.Segundo).Take(90).Select(c => Linea(lector, c)).ToList();

        var misPawns = lector.Posiciones.Keys.Where(lector.EsMiPawn).ToList();

        return new
        {
            archivo = Path.GetFileName(ruta),
            ok = true,
            duracion_seg = (replay.Info?.LengthInMs ?? 0) / 1000,
            cofres_mios = mios.Count,
            mios_abiertos = mios.Count(c => !c.CuentaComoDestruido),
            mios_destruidos = mios.Count(c => c.CuentaComoDestruido),
            mios_por_tipo = mios.GroupBy(c => c.Tipo).ToDictionary(g => g.Key, g => g.Count()),
            mios_por_metodo = mios.GroupBy(c => c.Metodo).ToDictionary(g => g.Key, g => g.Count()),
            grupos_cofre = lector.Grupos.Where(PareceCofre).OrderBy(g => g).ToList(),
            diag = new
            {
                grabador = lector.Grabador,
                cofres_vistos = lector.Cofres.Count,
                cofres_abiertos = abiertos.Count,
                cofres_destruidos = destruidos.Count,
                sin_autor = lector.Cofres.Values.Count(c => (c.Abierto || c.Destruido) && c.PawnAlAbrir == 0),
                duplicados = lector.Cofres.Values.Count(c => c.Duplicado),
                cofres_con_loc_actor = lector.Cofres.Values.Count(c => c.LocFuente == "actor"),
                cofres_con_loc_botin = lector.Cofres.Values.Count(c => c.LocFuente == "botin"),
                botin_visto = lector.Botin.Count,
                pawns_con_pos = lector.Posiciones.Count,
                mis_posiciones = misPawns.Sum(p => lector.Posiciones[p].Count),
                tipos_vistos = lector.Cofres.Values.GroupBy(c => c.Tipo).ToDictionary(g => g.Key, g => g.Count()),
                busquedas_mias = lector.Busquedas.Count(b => lector.EsMiPawn(b.Pawn)),
                golpes_total = lector.GolpesTotal,
                golpes_a_cofre = lector.GolpesACofre,
                detalle,
            },
        };
    }

    public static int Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        var lista = Path.Combine(AppContext.BaseDirectory, "cofres_conocidos.txt");
        var rutas = new List<string>(Predeterminados);
        if (File.Exists(lista))
        {
            rutas.AddRange(File.ReadAllLines(lista).Select(l => l.Trim()).Where(l => l.StartsWith("/")));
        }
        RegistrarCofres(rutas);

        var opciones = new JsonSerializerOptions { WriteIndented = false };
        foreach (var ruta in args)
        {
            object resultado;
            try
            {
                resultado = Analizar(ruta);
            }
            catch (Exception e)
            {
                resultado = new { archivo = Path.GetFileName(ruta), ok = false, error = e.GetType().Name + ": " + e.Message };
            }
            Console.WriteLine(JsonSerializer.Serialize(resultado, opciones));
        }
        return 0;
    }
}
'''


def today_key():
    return dt.date.today().isoformat()


def atomic_write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def open_path(path):
    try:
        if sys.platform == "win32":
            os.startfile(path)
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


# ---------------------------------------------------------------- data

class Store:
    """manual: corrections per day. replays: result per replay (replaced when a replay is re-read)."""

    def __init__(self):
        self.lock = threading.Lock()
        self.manual, self.replays = {}, {}
        self.reader_version = 0
        self.settings = {"delete_days": 3, "deleted": 0, "mb_freed": 0.0, "chest_types": [],
                         "language": "", "count_destroyed": True}
        try:
            with open(DATA_FILE, encoding="utf-8") as f:
                d = json.load(f)
            self.manual = {k: int(v) for k, v in d.get("manual", {}).items()}
            self.replays = d.get("replays", {})
            self.reader_version = int(d.get("reader_version", 0))
            self.settings.update(d.get("settings", {}))
        except Exception:
            pass

    def _save(self):
        atomic_write_json(DATA_FILE, {"app_version": APP_VERSION, "manual": self.manual, "replays": self.replays,
                                      "reader_version": self.reader_version, "settings": self.settings})

    def set_setting(self, key, value):
        with self.lock:
            self.settings[key] = value
            self._save()

    def setting(self, key):
        with self.lock:
            return self.settings.get(key)

    def add_manual(self, n):
        with self.lock:
            k = today_key()
            self.manual[k] = self.manual.get(k, 0) + n
            self._save()

    def set_replay(self, name, info):
        with self.lock:
            self.replays[name] = info
            self._save()

    def set_reader_version(self, v):
        with self.lock:
            self.reader_version = v
            self._save()

    def replay_count(self, r):
        if not r.get("ok"):
            return 0
        if self.settings.get("count_destroyed", True):
            return int(r.get("chests", 0))
        return int(r.get("opened", 0))

    def days(self):
        with self.lock:
            out = dict(self.manual)
            for r in self.replays.values():
                if r.get("ok") and r.get("day"):
                    out[r["day"]] = out.get(r["day"], 0) + self.replay_count(r)
            return {k: v for k, v in out.items() if v > 0}

    def replay_list(self):
        with self.lock:
            return dict(self.replays)


# ---------------------------------------------------------------- reader setup

class SetupError(Exception):
    def __init__(self, key):
        super().__init__(key)
        self.key = key


def run(cmd, log, cwd=None, timeout=1800):
    env = dict(os.environ, DOTNET_CLI_TELEMETRY_OPTOUT="1", DOTNET_NOLOGO="1",
               DOTNET_SKIP_FIRST_TIME_EXPERIENCE="1", DOTNET_ROOT=DOTNET_DIR)
    p = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", timeout=timeout, creationflags=NO_WINDOW)
    log.write(f"\n$ {' '.join(cmd)}\n{p.stdout}\n{p.stderr}\n")
    log.flush()
    return p


def install_reader(progress):
    """Downloads .NET (no admin rights needed) and builds the replay reader."""
    os.makedirs(TOOLS, exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as log:
        log.write(f"\n===== {dt.datetime.now():%Y-%m-%d %H:%M:%S}  app {APP_VERSION}  reader {READER_VERSION} =====\n")
        try:
            if not os.path.exists(DOTNET):
                progress("i_dotnet")
                script = os.path.join(TOOLS, "dotnet-install.ps1")
                urllib.request.urlretrieve(DOTNET_INSTALL, script)
                run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script,
                     "-Channel", "10.0", "-InstallDir", DOTNET_DIR], log)
                if not os.path.exists(DOTNET):
                    raise SetupError("e_dotnet")

            if not os.path.isdir(SRC_DIR):
                progress("i_reader")
                data = urllib.request.urlopen(REPO_ZIP, timeout=120).read()
                with zipfile.ZipFile(io.BytesIO(data)) as z:
                    z.extractall(SRC_DIR)

            roots = [os.path.join(SRC_DIR, d) for d in os.listdir(SRC_DIR)]
            root = next(r for r in roots if os.path.isdir(os.path.join(r, "src")))
            proj_dir = os.path.join(root, "src", "ChestCounter")
            os.makedirs(proj_dir, exist_ok=True)
            with open(os.path.join(proj_dir, "ChestCounter.csproj"), "w", encoding="utf-8") as f:
                f.write(CSPROJ)
            with open(os.path.join(proj_dir, "Program.cs"), "w", encoding="utf-8") as f:
                f.write(PROGRAM_CS)

            progress("i_build")
            shutil.rmtree(BIN_DIR, ignore_errors=True)
            p = run([DOTNET, "publish", os.path.join(proj_dir, "ChestCounter.csproj"), "-c", "Release",
                     "-o", BIN_DIR, "--nologo"], log, cwd=root)
            if p.returncode != 0 or not os.path.exists(READER_DLL):
                raise SetupError("e_build")
        except SetupError:
            raise
        except Exception as e:
            log.write(f"\n{type(e).__name__}: {e}\n")
            shutil.rmtree(SRC_DIR, ignore_errors=True)       # a broken download is fetched again next time
            if isinstance(e, (urllib.error.URLError, TimeoutError, ConnectionError)):
                raise SetupError("e_network")
            raise
    # Older reader versions are no longer needed.
    for d in os.listdir(TOOLS):
        full = os.path.join(TOOLS, d)
        if d.startswith("reader_v") and full != BIN_DIR:
            shutil.rmtree(full, ignore_errors=True)


# ---------------------------------------------------------------- background work

class Worker(threading.Thread):
    def __init__(self, store, events):
        super().__init__(daemon=True)
        self.store = store
        self.events = events
        self.proc = None
        self.stopping = False

    def msg(self, kind, data=None):
        self.events.put((kind, data))

    def stop(self):
        """Called when the window closes: never leave a reader running in the background."""
        self.stopping = True
        p = self.proc
        if p and p.poll() is None:
            try:
                p.kill()
            except Exception:
                pass

    def run(self):
        while not self.stopping:
            try:
                if not os.path.exists(READER_DLL) or self.store.reader_version != READER_VERSION:
                    install_reader(lambda key: self.msg("status", ("preparing", key)))
                    self.store.set_reader_version(READER_VERSION)
                    for k, v in self.store.replay_list().items():   # re-read with the new reader
                        if v.get("version") != READER_VERSION:
                            v["pending"] = True
                            self.store.set_replay(k, v)
                self.scan()
            except SetupError as e:
                self.msg("status", ("error", e.key))
                time.sleep(60)
                continue
            except Exception as e:
                self.msg("status", ("error", f"{type(e).__name__}: {e}"))
                time.sleep(30)
                continue
            time.sleep(10)

    def analyze(self, path, known_types):
        try:
            with open(os.path.join(BIN_DIR, "cofres_conocidos.txt"), "w", encoding="utf-8") as f:
                f.write("\n".join(sorted(known_types)))
        except OSError:
            pass
        name = os.path.basename(path)
        self.proc = subprocess.Popen([DOTNET, READER_DLL, path], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     text=True, encoding="utf-8", errors="replace", creationflags=NO_WINDOW,
                                     env=dict(os.environ, DOTNET_ROOT=DOTNET_DIR, DOTNET_CLI_TELEMETRY_OPTOUT="1"))
        try:
            out, err = self.proc.communicate(timeout=READ_TIMEOUT)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.communicate()
            return {"archivo": name, "ok": False, "error_key": "e_timeout"}
        finally:
            code = self.proc.returncode
            self.proc = None
        for line in out.splitlines():
            line = line.strip()
            if line.startswith("{"):
                try:
                    return json.loads(line)
                except Exception:
                    pass
        if self.stopping:
            return None
        with open(LOG_FILE, "a", encoding="utf-8") as log:
            log.write(f"\n[{name}] exit {code}\n{err[-2000:]}\n")
        return {"archivo": name, "ok": False, "error_key": "e_noreply"}

    def scan(self):
        if not os.path.isdir(DEMOS):
            self.msg("status", ("noreplays", None))
            return
        now = time.time()
        known = self.store.replay_list()
        ready = []
        files = [f for f in os.listdir(DEMOS) if f.lower().endswith(".replay")]
        for f in files:
            path = os.path.join(DEMOS, f)
            try:
                st = os.stat(path)
            except OSError:
                continue
            prev = known.get(f)
            if prev and prev.get("size") == st.st_size and prev.get("version") == READER_VERSION \
                    and not prev.get("pending"):
                continue
            if now - st.st_mtime < QUIET_SECONDS:        # Fortnite is still writing it
                continue
            ready.append((st.st_mtime, f, path, st))
        rereading = any(known.get(f, {}).get("version") not in (None, READER_VERSION) or known.get(f, {}).get("pending")
                        for _, f, _, _ in ready)
        ready.sort()
        for i, (mtime, f, path, st) in enumerate(ready):
            if self.stopping:
                return
            self.msg("status", ("reading", {"done": i, "total": len(ready), "reread": rereading}))
            known_types = set(self.store.setting("chest_types") or [])
            r = self.analyze(path, known_types)
            if r is None:
                return
            new_types = set(r.get("grupos_cofre") or []) - known_types
            if new_types:
                # New chest types: learn them and re-read every replay still on disk.
                self.store.set_setting("chest_types", sorted(known_types | new_types))
                for k, v in self.store.replay_list().items():
                    v["pending"] = True
                    self.store.set_replay(k, v)
                self.msg("status", ("learning", len(new_types)))
                return
            info = {
                "ok": bool(r.get("ok")),
                "chests": int(r.get("cofres_mios", 0)) if r.get("ok") else 0,
                "opened": int(r.get("mios_abiertos", 0)),
                "destroyed": int(r.get("mios_destruidos", 0)),
                "day": dt.date.fromtimestamp(mtime).isoformat(),
                "time": dt.datetime.fromtimestamp(mtime).strftime("%H:%M"),
                "size": st.st_size,
                "version": READER_VERSION,
                "types": r.get("mios_por_tipo", {}),
                "recorder_found": bool((r.get("diag") or {}).get("grabador")),
                "error": r.get("error"),
                "error_key": r.get("error_key"),
                "pending": False,
            }
            self.store.set_replay(f, info)
            self.msg("replay", (f, info))
        self.msg("status", ("watching", None))
        self.cleanup()

    def cleanup(self):
        """Deletes counted replays older than N days. Replays with errors are never deleted."""
        days = int(self.store.setting("delete_days") or 0)
        if days <= 0 or not os.path.isdir(DEMOS):
            return
        limit = time.time() - days * 86400
        known = self.store.replay_list()
        freed, count = 0, 0
        for f in os.listdir(DEMOS):
            if not f.lower().endswith(".replay"):
                continue
            info = known.get(f)
            path = os.path.join(DEMOS, f)
            try:
                st = os.stat(path)
            except OSError:
                continue
            if not info or not info.get("ok") or info.get("version") != READER_VERSION \
                    or info.get("size") != st.st_size or info.get("pending"):
                continue
            if st.st_mtime > limit:
                continue
            try:
                os.remove(path)
            except OSError:
                continue                      # Fortnite has it open: try again later
            freed += st.st_size
            count += 1
            info["deleted_file"] = True
            self.store.set_replay(f, info)
        if count:
            self.store.set_setting("deleted", int(self.store.setting("deleted") or 0) + count)
            self.store.set_setting("mb_freed", round(float(self.store.setting("mb_freed") or 0) + freed / 1e6, 1))
            self.msg("deleted", None)


# ---------------------------------------------------------------- UI helpers

class UI:
    """Sizes scaled to the screen DPI so the layout stays the same at 100 %, 125 %, 150 %…"""
    scale = 1.0
    family = "Segoe UI"

    @classmethod
    def px(cls, n):
        return int(round(n * cls.scale))

    @classmethod
    def font(cls, size, weight="normal", family=None):
        return (family or cls.family, size, weight)


def pick_family(root, wanted):
    fams = {f.lower(): f for f in tkfont.families(root)}
    for f in wanted:
        if f.lower() in fams:
            return fams[f.lower()]
    return "TkDefaultFont"


class WrapLabel(tk.Label):
    """Label that wraps its text to the width it is given."""

    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        self.bind("<Configure>", lambda e: self.configure(wraplength=max(50, e.width - 4)))


def dark_window(win):
    """Dark title bar on Windows 10/11."""
    if sys.platform != "win32":
        return
    try:
        win.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(win.winfo_id())
        val = ctypes.c_int(1)
        for attr in (20, 19):
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)) == 0:
                break
    except Exception:
        pass


# ---------------------------------------------------------------- matches window

class MatchesWindow(tk.Toplevel):
    def __init__(self, master, store):
        super().__init__(master)
        self.title(tr("m_title"))
        self.configure(bg=BG)
        px = UI.px
        cols = ("match", "total", "opened", "destroyed", "status")
        frame = tk.Frame(self, bg=BG)
        frame.pack(fill="both", expand=True, padx=px(14), pady=(px(14), px(8)))
        tv = ttk.Treeview(frame, columns=cols, show="headings")
        widths = {"match": 150, "total": 80, "opened": 90, "destroyed": 100, "status": 260}
        heads = {"match": "c_match", "total": "c_total", "opened": "c_opened", "destroyed": "c_destroyed",
                 "status": "c_status"}
        for c in cols:
            tv.heading(c, text=tr(heads[c]), anchor="w")
            tv.column(c, width=px(widths[c]), minwidth=px(60), anchor="w", stretch=(c == "status"))
        items = sorted(store.replay_list().items(), key=lambda kv: (kv[1].get("day", ""), kv[1].get("time", "")),
                       reverse=True)
        for name, r in items:
            if r.get("pending"):
                status = tr("s_pending")
            elif r.get("ok"):
                status = tr("s_ok") if r.get("recorder_found", True) else tr("s_norec")
            else:
                status = tr("s_err", e=tr(r["error_key"]) if r.get("error_key") else (r.get("error") or "?"))
            when = f"{r.get('day', '')} {r.get('time', '')}".strip()
            if r.get("ok"):
                nums = (store.replay_count(r), r.get("opened", 0), r.get("destroyed", 0))
            else:
                nums = ("—", "—", "—")
            tv.insert("", "end", values=(when, *nums, status))
        sb = ttk.Scrollbar(frame, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=sb.set)
        tv.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        types = store.setting("chest_types") or []
        tk.Label(self, text=tr("types"), bg=BG, fg=INK, font=UI.font(10, "bold"), anchor="w").pack(
            fill="x", padx=px(14))
        txt = tk.Text(self, height=5, bg=PANEL, fg=MUTED, font=("Consolas", 9), relief="flat",
                      highlightthickness=0, padx=px(8), pady=px(6))
        txt.insert("1.0", "\n".join(g.rsplit(".", 1)[-1] for g in types) or "—")
        txt.configure(state="disabled")
        txt.pack(fill="x", padx=px(14), pady=(px(4), px(14)))
        self.geometry(f"{px(760)}x{px(460)}")
        self.minsize(px(520), px(320))
        dark_window(self)


# ---------------------------------------------------------------- help window

class HelpWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        px = UI.px
        self.title(tr("help"))
        self.configure(bg=BG)
        self.transient(master)
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=px(22), pady=px(18))
        wrap = px(500)
        tk.Label(body, text=tr("help"), bg=BG, fg=INK, font=UI.font(14, "bold"), anchor="w").pack(fill="x")
        for i in range(1, 6):
            first = i == 1
            tk.Label(body, text=tr(f"h{i}_t"), bg=BG, fg=GOLD if first else INK, font=UI.font(11, "bold"),
                     anchor="w", justify="left", wraplength=wrap).pack(fill="x", pady=(px(14), px(3)))
            tk.Label(body, text=tr(f"h{i}"), bg=BG, fg=INK if first else MUTED, font=UI.font(10), anchor="w",
                     justify="left", wraplength=wrap).pack(fill="x")
        btns = tk.Frame(body, bg=BG)
        btns.pack(fill="x", pady=(px(18), 0))
        ttk.Button(btns, text=tr("close"), style="Gold.TButton", command=self.destroy).pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())
        self.resizable(False, False)
        dark_window(self)



# ---------------------------------------------------------------- settings window

class SettingsWindow(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        store = app.store
        px = UI.px
        self.title(tr("set_title"))
        self.configure(bg=BG)
        self.resizable(False, False)
        self.transient(app.root)
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=px(20), pady=px(18))
        body.columnconfigure(1, weight=1)

        tk.Label(body, text=tr("language"), bg=BG, fg=INK, font=UI.font(10)).grid(row=0, column=0, sticky="w",
                                                                                 pady=(0, px(12)))
        names = [LANGS[c] for c in LANGS]
        self.v_lang = tk.StringVar(value=LANGS[_lang])
        cb = ttk.Combobox(body, values=names, textvariable=self.v_lang, state="readonly", width=16,
                          font=UI.font(10))
        cb.grid(row=0, column=1, sticky="w", padx=(px(10), 0), pady=(0, px(12)))
        cb.bind("<<ComboboxSelected>>", self._lang_changed)

        self.v_destroyed = tk.BooleanVar(value=bool(store.setting("count_destroyed")))
        ttk.Checkbutton(body, text=tr("count_destroyed"), variable=self.v_destroyed, style="Dark.TCheckbutton",
                        command=self._destroyed_changed).grid(row=1, column=0, columnspan=2, sticky="w",
                                                              pady=(0, px(12)))

        row = tk.Frame(body, bg=BG)
        row.grid(row=2, column=0, columnspan=2, sticky="w")
        tk.Label(row, text=tr("autodelete"), bg=BG, fg=INK, font=UI.font(10)).pack(side="left")
        self.v_days = tk.StringVar(value=str(store.setting("delete_days")))
        sp = ttk.Spinbox(row, from_=0, to=365, increment=1, width=4, textvariable=self.v_days,
                         command=self._save_days, font=UI.font(10))
        sp.pack(side="left", padx=px(8))
        sp.bind("<FocusOut>", lambda e: self._save_days())
        sp.bind("<Return>", lambda e: self._save_days())
        tk.Label(row, text=tr("days_never"), bg=BG, fg=INK, font=UI.font(10)).pack(side="left")
        self.lbl_clean = tk.Label(body, text="", bg=BG, fg=MUTED, font=UI.font(9), justify="left", anchor="w",
                                  wraplength=px(440))
        self.lbl_clean.grid(row=3, column=0, columnspan=2, sticky="w", pady=(px(6), px(16)))
        self._show_clean()

        btns = tk.Frame(body, bg=BG)
        btns.grid(row=4, column=0, columnspan=2, sticky="ew")
        ttk.Button(btns, text=tr("open_data"), command=lambda: open_path(DATA_DIR)).pack(side="left")
        ttk.Button(btns, text=tr("close"), style="Gold.TButton", command=self.destroy).pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())
        dark_window(self)
        self.grab_set()

    def _lang_changed(self, _e=None):
        name = self.v_lang.get()
        code = next(c for c, n in LANGS.items() if n == name)
        self.app.store.set_setting("language", code)
        self.destroy()
        self.app.relabel(code)
        SettingsWindow(self.app)

    def _destroyed_changed(self):
        self.app.store.set_setting("count_destroyed", bool(self.v_destroyed.get()))
        self.app.refresh()

    def _save_days(self):
        try:
            v = max(0, min(365, int(self.v_days.get())))
        except ValueError:
            v = int(self.app.store.setting("delete_days") or 0)
        self.v_days.set(str(v))
        self.app.store.set_setting("delete_days", v)
        self._show_clean()

    def _show_clean(self):
        s = self.app.store
        n = int(s.setting("deleted") or 0)
        days = int(s.setting("delete_days") or 0)
        txt = tr("clean_off") if days == 0 else tr("clean_on", n=days)
        if n:
            txt += "\n" + tr("clean_done", n=n, mb=fmt_int(int(round(float(s.setting("mb_freed") or 0)))))
        self.lbl_clean.config(text=txt)


# ---------------------------------------------------------------- main window

class App:
    def __init__(self, root, start_worker=True):
        self.root = root
        self.store = Store()
        set_language(self.store.setting("language") or detect_language())
        self.events = queue.Queue()
        self.last_replay = None
        self.state = ("starting", None)

        UI.scale = max(1.0, root.winfo_fpixels("1i") / 96.0)
        UI.family = pick_family(root, ["Segoe UI", "Helvetica Neue", "Arial", "Liberation Sans", "DejaVu Sans"])
        self.black = pick_family(root, ["Segoe UI Black", "Arial Black", UI.family])
        root.configure(bg=BG)
        self._style()
        self.main = None
        self._build()
        self._size_window()

        self.worker = Worker(self.store, self.events)
        if start_worker:
            self.worker.start()
        root.protocol("WM_DELETE_WINDOW", self.close)

        self.refresh()
        if not self.store.setting("help_seen"):
            self.store.set_setting("help_seen", True)
            root.after(600, lambda: HelpWindow(self.root))
        root.after(100, self._pump)
        root.after(60000, self._minute)
        dark_window(root)

    def close(self):
        self.worker.stop()
        self.root.destroy()

    def _style(self):
        px = UI.px
        s = ttk.Style(self.root)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure("TButton", background=PANEL, foreground=INK, bordercolor=LINE, lightcolor=PANEL,
                    darkcolor=PANEL, focusthickness=1, focuscolor=SKY, padding=(px(12), px(7)), font=UI.font(10))
        s.map("TButton", background=[("active", LINE), ("disabled", BG)], foreground=[("disabled", MUTED)])
        s.configure("Gold.TButton", background=GOLD, foreground="#2b1a00", lightcolor=GOLD, darkcolor=GOLD,
                    font=UI.font(10, "bold"))
        s.map("Gold.TButton", background=[("active", "#ffe07a")])
        s.configure("Small.TButton", padding=(px(10), px(3)), font=UI.font(10, "bold"))
        s.configure("Help.TButton", padding=(px(4), px(1)), font=UI.font(11, "bold"), foreground=GOLD,
                    background=PANEL, bordercolor=GOLD, lightcolor=PANEL, darkcolor=PANEL, anchor="center")
        s.configure("Link.TButton", background=BG, foreground=WARN, bordercolor=BG, lightcolor=BG, darkcolor=BG,
                    padding=(px(6), px(2)), font=UI.font(9, "bold"))
        s.map("Link.TButton", background=[("active", PANEL)])
        s.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=INK, rowheight=px(26),
                    bordercolor=LINE, lightcolor=LINE, darkcolor=LINE, font=UI.font(10))
        s.configure("Treeview.Heading", background=BG, foreground=MUTED, font=UI.font(9, "bold"), relief="flat",
                    padding=(px(6), px(4)))
        s.map("Treeview", background=[("selected", LINE)])
        s.map("Treeview.Heading", background=[("active", PANEL)])
        s.configure("Dark.TCheckbutton", background=BG, foreground=INK, font=UI.font(10), indicatorcolor=PANEL,
                    wraplength=px(430))
        s.map("Dark.TCheckbutton", background=[("active", BG)], indicatorcolor=[("selected", GOLD)])
        s.configure("TCombobox", fieldbackground=PANEL, background=PANEL, foreground=INK, arrowcolor=INK,
                    bordercolor=LINE, selectbackground=PANEL, selectforeground=INK)
        s.map("TCombobox", fieldbackground=[("readonly", PANEL)], foreground=[("readonly", INK)])
        s.configure("TSpinbox", fieldbackground=PANEL, background=PANEL, foreground=INK, arrowcolor=INK,
                    bordercolor=LINE)
        s.configure("Vertical.TScrollbar", background=LINE, troughcolor=PANEL, bordercolor=PANEL, arrowcolor=MUTED,
                    lightcolor=LINE, darkcolor=LINE, gripcount=0)
        s.map("Vertical.TScrollbar", background=[("active", MUTED)])
        self.root.option_add("*TCombobox*Listbox.background", PANEL)
        self.root.option_add("*TCombobox*Listbox.foreground", INK)
        self.root.option_add("*TCombobox*Listbox.selectBackground", LINE)

    def _build(self):
        px = UI.px
        r = self.root
        r.title(tr("app"))
        if self.main is not None:
            self.main.destroy()
        m = self.main = tk.Frame(r, bg=BG)
        m.pack(fill="both", expand=True, padx=px(20), pady=(px(16), px(16)))

        top = tk.Frame(m, bg=BG)
        top.pack(fill="x")
        tk.Label(top, text=tr("app"), bg=BG, fg=INK, font=UI.font(15, "bold", self.black)).pack(side="left")
        ttk.Button(top, text="?", style="Help.TButton", width=2, command=lambda: HelpWindow(self.root)).pack(
            side="right", padx=(px(10), 0))
        self.lbl_state = tk.Label(top, text="", bg=BG, fg=MUTED, font=UI.font(9, "bold"))
        self.lbl_state.pack(side="right")

        tk.Label(m, text=tr("total"), bg=BG, fg=MUTED, font=UI.font(9, "bold")).pack(pady=(px(14), 0))
        self.lbl_total = tk.Label(m, text="0", bg=BG, fg=GOLD, font=UI.font(60, "bold", self.black))
        self.lbl_total.pack()

        today_row = tk.Frame(m, bg=BG)
        today_row.pack()
        self.lbl_today = tk.Label(today_row, text="", bg=BG, fg=INK, font=UI.font(13))
        self.lbl_today.pack(side="left")
        self.lbl_last = WrapLabel(m, text="", bg=BG, fg=MUTED, font=UI.font(9), justify="center")
        self.lbl_last.pack(fill="x", pady=(px(2), 0))

        # Status / progress line, with a details button for errors.
        info = tk.Frame(m, bg=BG)
        info.pack(fill="x", pady=(px(10), 0))
        self.lbl_info = WrapLabel(info, text="", bg=BG, fg=MUTED, font=UI.font(9), justify="center")
        self.lbl_info.pack(fill="x")
        self.btn_details = ttk.Button(info, text=tr("details"), style="Link.TButton", command=lambda: open_path(LOG_FILE))

        # Buttons: main actions, then the manual correction.
        btns = tk.Frame(m, bg=BG)
        btns.pack(fill="x", pady=(px(12), 0))
        for i in range(3):
            btns.columnconfigure(i, weight=1, uniform="b")
        ttk.Button(btns, text=tr("matches"), command=lambda: MatchesWindow(self.root, self.store)).grid(
            row=0, column=0, sticky="ew", padx=(0, px(4)))
        ttk.Button(btns, text=tr("folder"), command=self.open_demos).grid(row=0, column=1, sticky="ew", padx=px(4))
        ttk.Button(btns, text=tr("settings"), command=lambda: SettingsWindow(self)).grid(
            row=0, column=2, sticky="ew", padx=(px(4), 0))

        corr = tk.Frame(m, bg=BG)
        corr.pack(pady=(px(10), 0))
        tk.Label(corr, text=tr("correction"), bg=BG, fg=MUTED, font=UI.font(9)).pack(side="left", padx=(0, px(8)))
        ttk.Button(corr, text="−1", style="Small.TButton", width=3, command=lambda: self.change(-1)).pack(
            side="left", padx=(0, px(4)))
        ttk.Button(corr, text="+1", style="Small.TButton", width=3, command=lambda: self.change(1)).pack(side="left")

        tk.Label(m, text=tr("last14"), bg=BG, fg=INK, font=UI.font(11, "bold"), anchor="w").pack(
            fill="x", pady=(px(16), px(4)))
        self.cv = tk.Canvas(m, height=px(120), bg=PANEL, highlightthickness=1, highlightbackground=LINE)
        self.cv.pack(fill="x")
        self.cv.bind("<Configure>", lambda e: self.draw_chart())

        self.lbl_stats = WrapLabel(m, text="", bg=BG, fg=MUTED, font=UI.font(9), justify="left", anchor="w")
        self.lbl_stats.pack(fill="x", pady=(px(8), 0))

        tk.Label(m, text=tr("per_day"), bg=BG, fg=INK, font=UI.font(11, "bold"), anchor="w").pack(
            fill="x", pady=(px(12), px(4)))
        tf = tk.Frame(m, bg=BG)
        tf.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(tf, columns=("day", "n"), show="headings", height=5)
        self.tree.heading("day", text=tr("col_day"), anchor="w")
        self.tree.heading("n", text=tr("col_chests"), anchor="e")
        self.tree.column("day", anchor="w", stretch=True, width=px(300))
        self.tree.column("n", anchor="e", width=px(100), stretch=False)
        sb = ttk.Scrollbar(tf, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

    def _size_window(self):
        px = UI.px
        self.root.update_idletasks()
        w = max(px(560), self.root.winfo_reqwidth())
        h = max(px(760), self.root.winfo_reqheight())
        sh = self.root.winfo_screenheight()
        h = min(h, int(sh * 0.9))
        self.root.geometry(f"{w}x{h}")
        self.root.minsize(max(px(480), self.main.winfo_reqwidth() + px(40)), min(px(640), h))

    def relabel(self, code):
        """Rebuild the window in another language."""
        set_language(code)
        self._build()
        self._style()
        self._status(*self.state)
        self.refresh()

    def change(self, n):
        self.store.add_manual(n)
        self.refresh()

    def open_demos(self):
        if os.path.isdir(DEMOS):
            open_path(DEMOS)
        else:
            messagebox.showinfo(tr("app"), tr("nofolder"), parent=self.root)

    # --- background events
    def _pump(self):
        try:
            while True:
                kind, data = self.events.get_nowait()
                if kind == "status":
                    self.state = data
                    self._status(*data)
                elif kind == "replay":
                    name, info = data
                    self.last_replay = info
                    self.refresh()
                    if info.get("ok") and info.get("chests"):
                        self._flash()
        except queue.Empty:
            pass
        self.root.after(200, self._pump)

    def _status(self, kind, data):
        self.btn_details.pack_forget()
        color, label, text = MUTED, "", ""
        if kind == "starting":
            color, label = MUTED, tr("st_starting")
        elif kind == "preparing":
            color, label, text = GOLD, tr("st_preparing"), tr(data)
        elif kind == "error":
            color, label = WARN, tr("st_error")
            text = tr(data) if data in T["en"] else str(data).splitlines()[0][:180]
            self.btn_details.pack(pady=(px_(4), 0))
        elif kind == "noreplays":
            color, label, text = WARN, tr("st_noreplays"), tr("i_noreplays")
        elif kind == "learning":
            color, label, text = GOLD, tr("st_learning"), tr("i_learning", n=data)
        elif kind == "reading":
            color, label = GOLD, tr("st_reading")
            text = tr("i_reading", done=data["done"], total=data["total"])
            if data.get("reread"):
                text += "\n" + tr("i_reread")
        elif kind == "watching":
            n = len([r for r in self.store.replay_list().values() if r.get("ok")])
            color, label, text = OK, tr("st_watching"), tr("i_watching", n=n)
        self.lbl_state.config(text="● " + label, fg=color)
        self.lbl_info.config(text=text, fg=WARN if kind == "error" else (GOLD if color == GOLD else MUTED))

    def _flash(self):
        self.lbl_total.config(fg="#ffffff")
        self.root.after(250, lambda: self.lbl_total.config(fg=GOLD))

    def _minute(self):
        self.refresh()
        self.root.after(60000, self._minute)

    # --- drawing
    def refresh(self):
        days = self.store.days()
        total = sum(days.values())
        t = days.get(today_key(), 0)
        self.lbl_total.config(text=fmt_int(total))
        self.lbl_today.config(text=tr("today", n=fmt_int(t)))
        lr = self.last_replay
        if lr and lr.get("ok"):
            n = self.store.replay_count(lr)
            if lr.get("destroyed") and self.store.setting("count_destroyed"):
                self.lbl_last.config(text=tr("last_split", time=lr["time"], n=n, o=lr.get("opened", 0),
                                             d=lr["destroyed"]))
            else:
                self.lbl_last.config(text=tr("last", time=lr["time"], n=n))

        if days:
            best = max(days, key=days.get)
            self.lbl_stats.config(text=tr("stats", d=len(days), a=fmt_dec(total / len(days)), b=fmt_int(days[best]),
                                          date=fmt_date(dt.date.fromisoformat(best))))
        else:
            self.lbl_stats.config(text=tr("no_stats"))

        self.tree.delete(*self.tree.get_children())
        for k in sorted(days, reverse=True):
            label = tr("today_short") if k == today_key() else fmt_date(dt.date.fromisoformat(k))
            self.tree.insert("", "end", values=(label, fmt_int(days[k])))
        self.draw_chart()

    def draw_chart(self):
        px = UI.px
        cv = self.cv
        cv.delete("all")
        w = cv.winfo_width()
        h = cv.winfo_height()
        if w < 50:
            return
        days = self.store.days()
        today = dt.date.today()
        seq = [today - dt.timedelta(days=i) for i in range(13, -1, -1)]
        vals = [days.get(d.isoformat(), 0) for d in seq]
        mx = max(1, max(vals))
        pad_x, top, bottom = px(10), px(20), px(22)
        slot = (w - 2 * pad_x) / 14
        bw = slot * 0.62
        small = UI.font(8)
        for i, (d, v) in enumerate(zip(seq, vals)):
            cx = pad_x + slot * i + slot / 2
            bh = (h - top - bottom) * v / mx
            color = GOLD if i == 13 else SKY
            if v:
                cv.create_rectangle(cx - bw / 2, h - bottom - bh, cx + bw / 2, h - bottom, fill=color, width=0)
                cv.create_text(cx, h - bottom - bh - px(8), text=fmt_int(v), fill=color if i == 13 else MUTED,
                               font=small)
            cv.create_text(cx, h - px(10), text=tr("today_short") if i == 13 else str(d.day),
                           fill=GOLD if i == 13 else MUTED, font=small)
        cv.create_line(pad_x, h - bottom, w - pad_x, h - bottom, fill=LINE)


def px_(n):
    return UI.px(n)


def main():
    if sys.platform == "win32":
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)      # sharp text on high-DPI screens
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("ChestCounter.App")
        except Exception:
            pass
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
