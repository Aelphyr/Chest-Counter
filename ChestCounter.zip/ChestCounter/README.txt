CHEST COUNTER FOR FORTNITE  (v1.0)
==================================
English below · Español más abajo

Counts the chests you loot in Fortnite, automatically, with a total and a count per day.
It reads the replays Fortnite saves after each match. Inside each replay every chest records who
opened it, so only YOUR chests are counted: normal, rare and spirit chests, with or without the
"Search" prompt, and chests you break open with the pickaxe. It does not depend on quests.

It never touches the game or its memory. It only reads replay files Fortnite already writes to your PC.

REQUIREMENTS
- Windows 10 or 11.
- Python 3 (the start file offers to install it for you if it is missing).
- About 300 MB free disk space for .NET 10, downloaded automatically the first time (no admin rights needed).

FIRST USE
1. In Fortnite: Settings > Game > Replays > Record Replays (Battle Royale) = ON.
2. Double-click "Start Chest Counter.bat".
3. The first start downloads and builds the replay reader (2-5 minutes). Leave the window open.
4. Play. About 2 minutes after each match ends, its chests are added on their own.
   This also works with "Play again" from spectator mode: each match is its own replay.

SETTINGS (button "Settings")
- Language: English, Español, Português, Français, Deutsch.
- Count destroyed chests: turn off to count only opened chests.
- Delete counted replays after N days, to keep your disk free (0 = never). Replays that
  failed to read are never deleted.

GOOD TO KNOW
- Chests destroyed with explosives from far away (more than 8 m) are not credited to you:
  Fortnite does not store your own hits in the replay, so the app checks who was next to the chest.
- When the app gets an improved reader it re-reads your matches, and the total can go down a little
  while it fixes old counts.
- The "?" button (top right) shows these instructions inside the app.
- "Matches" lists every match read. "Manual correction" adds or removes chests on today.
- Your data: %APPDATA%\ChestCounter\data.json   ·   Reader and log: %LOCALAPPDATA%\ChestCounter
- To uninstall, delete this folder and the two folders above.

Credits: replay parsing by FortniteReplayDecompressor (Shiqan) and its fork MoreFortniteReplayDecompression
(Cristiano3120), MIT license. Not affiliated with or endorsed by Epic Games. Fortnite is a trademark of
Epic Games, Inc.


----------------------------------------------------------------------------------------------------
CONTADOR DE COFRES PARA FORTNITE  (v1.0)

Cuenta automáticamente los cofres que consigues en Fortnite, con el total y los cofres de cada día.
Lee las repeticiones que Fortnite guarda al terminar cada partida. En cada repetición, cada cofre indica
quién lo abrió, así que solo se cuentan TUS cofres: normales, raros y de espíritu, con o sin el botón de
"Buscar", y también los que rompes con el pico. No depende de misiones.

No toca el juego ni su memoria. Solo lee las repeticiones que Fortnite ya guarda en tu PC.

REQUISITOS
- Windows 10 u 11.
- Python 3 (si falta, el archivo de inicio se ofrece a instalarlo).
- Unos 300 MB libres para .NET 10, que se descarga solo la primera vez (no hace falta ser administrador).

PRIMER USO
1. En Fortnite: Ajustes > Juego > Repeticiones > Grabar repeticiones (Battle Royale) = ACTIVADO.
2. Haz doble clic en "Start Chest Counter.bat".
3. La primera vez descarga y compila el lector de repeticiones (2-5 minutos). Deja la ventana abierta.
4. Juega. Unos 2 minutos después de cada partida, sus cofres se suman solos.
   También funciona con "Volver a jugar" desde el modo espectador: cada partida es una repetición distinta.

AJUSTES (botón "Ajustes")
- Idioma: English, Español, Português, Français, Deutsch.
- Contar cofres destruidos: desactívalo para contar solo los cofres abiertos.
- Borrar las repeticiones ya contadas tras N días, para no llenar el disco (0 = nunca). Las que dieron
  error nunca se borran.

CONVIENE SABER
- Los cofres destruidos con explosivos desde lejos (más de 8 m) no se te atribuyen: Fortnite no guarda
  tus propios golpes en la repetición, así que la app mira quién estaba al lado del cofre.
- Cuando la app recibe un lector mejorado, vuelve a leer tus partidas y el total puede bajar un poco
  mientras corrige los conteos antiguos.
- El botón "?" (arriba a la derecha) muestra estas instrucciones dentro de la app.
- "Partidas" muestra cada partida leída. "Corrección manual" suma o resta cofres al día de hoy.
- Tus datos: %APPDATA%\ChestCounter\data.json   ·   Lector y registro: %LOCALAPPDATA%\ChestCounter
- Para desinstalar, borra esta carpeta y las dos carpetas anteriores.

Créditos: lectura de repeticiones con FortniteReplayDecompressor (Shiqan) y su fork
MoreFortniteReplayDecompression (Cristiano3120), licencia MIT. Sin relación ni respaldo de Epic Games.
Fortnite es una marca de Epic Games, Inc.
