@echo off
setlocal
cd /d "%~dp0"
title Chest Counter
set "APP=%~dp0chest_counter.py"

rem 1) Python launcher (installed with Python from python.org)
py -3 -c "import tkinter" >nul 2>&1
if not errorlevel 1 (
  start "" pyw -3 "%APP%"
  exit /b 0
)

rem 2) python.exe on PATH (the Microsoft Store shortcut fails this test and is skipped)
set "PYW="
for /f "delims=" %%P in ('python -c "import sys,os,tkinter;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))" 2^>nul') do set "PYW=%%P"
if defined PYW if exist "%PYW%" (
  start "" "%PYW%" "%APP%"
  exit /b 0
)

rem 3) Per-user installs in the default folder
for %%V in (314 313 312 311 310) do (
  if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\pythonw.exe" (
    start "" "%LOCALAPPDATA%\Programs\Python\Python%%V\pythonw.exe" "%APP%"
    exit /b 0
  )
)

echo.
echo   Chest Counter needs Python 3 (free, about 30 MB). It is not installed yet.
echo   Chest Counter necesita Python 3 (gratis, unos 30 MB). Aun no esta instalado.
echo.
choice /c YN /m "  Install it now? / Instalarlo ahora?"
if errorlevel 2 goto manual

where winget >nul 2>&1
if errorlevel 1 goto manual
winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
if exist "%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe" (
  start "" "%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe" "%APP%"
  exit /b 0
)

:manual
echo.
echo   Install Python 3 from the page that is opening now, then run this file again.
echo   Instala Python 3 desde la pagina que se esta abriendo y vuelve a abrir este archivo.
start "" "https://www.python.org/downloads/windows/"
echo.
pause
